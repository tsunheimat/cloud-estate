# Ansible Collection - techprober.apt

Documentation for the collection.

## Using roles in this collection

Install the collection

```bash
ansible-galaxy collection install techprober.apt
```
