# Ansible Collection Role - techprober.minio.upgrade
